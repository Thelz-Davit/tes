<?php
    $conn = mysqli_connect("localhost","root","","pertemuan3") 
    or die("Can't connect to the database");
?>